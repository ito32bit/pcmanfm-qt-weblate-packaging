<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es">
<context>
    <name>AboutDialog</name>
    <message>
        <location filename="../about.ui" line="14"/>
        <source>About</source>
        <translation>Acerca de</translation>
    </message>
    <message>
        <location filename="../about.ui" line="25"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt; font-weight:600;&quot;&gt;PCManFM-Qt&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-size:16pt; font-weight:600;&quot;&gt;PCManFM-Qt&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../about.ui" line="48"/>
        <source>Lightweight file manager</source>
        <translation>Administrador de archivos ligero</translation>
    </message>
    <message>
        <location filename="../about.ui" line="58"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;https://lxqt.org/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;https://lxqt.org/&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;a href=&quot;https://lxqt.org/&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;https://lxqt.org/&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../about.ui" line="78"/>
        <source>Authors</source>
        <translation>Autores</translation>
    </message>
    <message>
        <location filename="../about.ui" line="87"/>
        <source>Programming:
* Hong Jen Yee (PCMan) &lt;pcman.tw@gmail.com&gt;
</source>
        <translation>Programación:
* Hong Jen Yee (PCMan) &lt;pcman.tw@gmail.com&gt;
</translation>
    </message>
    <message>
        <location filename="../about.ui" line="100"/>
        <source>License</source>
        <translation>Licencia</translation>
    </message>
    <message>
        <location filename="../about.ui" line="109"/>
        <source>PCManFM-Qt File Manager

Copyright (C) 2009 - 2014 洪任諭 (Hong Jen Yee)

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.</source>
        <translation>PCManFM-Qt File Manager

Derechos de autor (C) 2009 - 2014 洪任諭 (Hong Jen Yee)

Este programa es software libre; puede redistribuirlo y/o
modificarlo bajo los términos de la Licencia Pública General de GNU
de acuerdo a lo publicado por la Free Software Foundation; en su versión 2
de la Lincencia, o (a su parecer) cualquier versión posterior.

Este programa es distribuído con la esperanza que será de utilidad,
pero SIN NINGUNA GARANTÍA; sin siquiera la garantía implícita de
COMERCIABILIDAD o IDONEIDAD PARA UN PROPÓSITO PARTICULAR. Ver la
Licencia Pública General de GNU para más detalles.

Usted debió haber recibido una copia de la Licencia Pública General de GNU
junto con este programa; si no fué así, escriba a la Free Software 
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.</translation>
    </message>
</context>
<context>
    <name>AutoRunDialog</name>
    <message>
        <location filename="../autorun.ui" line="14"/>
        <source>Removable medium is inserted</source>
        <translation>Un medio removible esta insertado</translation>
    </message>
    <message>
        <location filename="../autorun.ui" line="33"/>
        <source>&lt;b&gt;Removable medium is inserted&lt;/b&gt;</source>
        <translation>&lt;b&gt;Un medio removible esta insertado&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../autorun.ui" line="40"/>
        <source>Type of medium:</source>
        <translation>Tipo de medio:</translation>
    </message>
    <message>
        <location filename="../autorun.ui" line="47"/>
        <source>Detecting...</source>
        <translation>Detectando...</translation>
    </message>
    <message>
        <location filename="../autorun.ui" line="56"/>
        <source>Please select the action you want to perform:</source>
        <translation>Seleccione como desea proceder:</translation>
    </message>
</context>
<context>
    <name>BulkRenameDialog</name>
    <message>
        <location filename="../bulk-rename.ui" line="6"/>
        <source>Bulk Rename</source>
        <translation>Renombrar varios archivos</translation>
    </message>
    <message>
        <location filename="../bulk-rename.ui" line="48"/>
        <source># will be replaced by numbers starting with:</source>
        <translation># se reemplazará por números empezando por:</translation>
    </message>
    <message>
        <location filename="../bulk-rename.ui" line="71"/>
        <source>Rename selected files to:</source>
        <translation>Renombrar los archivos seleccionados a:</translation>
    </message>
    <message>
        <location filename="../bulk-rename.ui" line="84"/>
        <source>Name#</source>
        <translation>Nombre#</translation>
    </message>
</context>
<context>
    <name>ConnectServerDialog</name>
    <message>
        <location filename="../connect.ui" line="14"/>
        <source>Connect to remote server</source>
        <translation>Conectarse a un servidor remoto</translation>
    </message>
    <message>
        <location filename="../connect.ui" line="23"/>
        <source>Anonymous &amp;login</source>
        <translation>Iniciar sesión de forma &amp;anónima</translation>
    </message>
    <message>
        <location filename="../connect.ui" line="36"/>
        <source>Login as &amp;user:</source>
        <translation>Iniciar sesión como el &amp;usuario:</translation>
    </message>
    <message>
        <location filename="../connect.ui" line="65"/>
        <source>Specify remote folder to connect</source>
        <translation>Especifique la carpeta remota que desea conectar</translation>
    </message>
    <message>
        <location filename="../connect.ui" line="72"/>
        <source>Type:</source>
        <translation>Tipo:</translation>
    </message>
    <message>
        <location filename="../connect.ui" line="79"/>
        <source>Port:</source>
        <translation>Puerto:</translation>
    </message>
    <message>
        <location filename="../connect.ui" line="86"/>
        <source>Path:</source>
        <translation>Dirección:</translation>
    </message>
    <message>
        <location filename="../connect.ui" line="96"/>
        <source>Host:</source>
        <translation>Servidor:</translation>
    </message>
</context>
<context>
    <name>DesktopEntryDialog</name>
    <message>
        <location filename="../desktopentrydialog.ui" line="14"/>
        <source>Create Launcher</source>
        <translation>Crear un lanzador</translation>
    </message>
    <message>
        <location filename="../desktopentrydialog.ui" line="38"/>
        <source>Name:</source>
        <translation>Nombre:</translation>
    </message>
    <message>
        <location filename="../desktopentrydialog.ui" line="55"/>
        <source>Description:</source>
        <translation>Descripción:</translation>
    </message>
    <message>
        <location filename="../desktopentrydialog.ui" line="69"/>
        <source>Comment:</source>
        <translation>Comentario:</translation>
    </message>
    <message>
        <location filename="../desktopentrydialog.ui" line="83"/>
        <source>Command:</source>
        <translation>Comando:</translation>
    </message>
    <message>
        <location filename="../desktopentrydialog.ui" line="99"/>
        <location filename="../desktopentrydialog.ui" line="127"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../desktopentrydialog.ui" line="108"/>
        <source>Icon:</source>
        <translation>Icono:</translation>
    </message>
    <message>
        <location filename="../desktopentrydialog.ui" line="136"/>
        <location filename="../desktopentrydialog.ui" line="146"/>
        <source>Run in terminal?</source>
        <translation>¿Quiere ejecutarlo en la terminal?</translation>
    </message>
    <message>
        <location filename="../desktopentrydialog.ui" line="139"/>
        <source>Terminal:</source>
        <translation>Terminal:</translation>
    </message>
    <message>
        <location filename="../desktopentrydialog.ui" line="150"/>
        <source>No</source>
        <translation>No</translation>
    </message>
    <message>
        <location filename="../desktopentrydialog.ui" line="155"/>
        <source>Yes</source>
        <translation>Sí</translation>
    </message>
    <message>
        <location filename="../desktopentrydialog.ui" line="163"/>
        <source>Type:</source>
        <translation>Tipo:</translation>
    </message>
    <message>
        <location filename="../desktopentrydialog.ui" line="171"/>
        <source>Application</source>
        <translation>Aplicación</translation>
    </message>
    <message>
        <location filename="../desktopentrydialog.ui" line="176"/>
        <source>Link</source>
        <translation>Enlace</translation>
    </message>
</context>
<context>
    <name>DesktopFolder</name>
    <message>
        <location filename="../desktop-folder.ui" line="14"/>
        <source>Form</source>
        <translation>Formulario</translation>
    </message>
    <message>
        <location filename="../desktop-folder.ui" line="23"/>
        <source>Desktop</source>
        <translation>Escritorio</translation>
    </message>
    <message>
        <location filename="../desktop-folder.ui" line="29"/>
        <source>Desktop folder:</source>
        <translation>Carpeta de escritorio:</translation>
    </message>
    <message>
        <location filename="../desktop-folder.ui" line="36"/>
        <source>Image file</source>
        <translation>Archivo de imagen</translation>
    </message>
    <message>
        <location filename="../desktop-folder.ui" line="42"/>
        <source>Folder path</source>
        <translation>Dirección de la carpeta</translation>
    </message>
    <message>
        <location filename="../desktop-folder.ui" line="49"/>
        <source>&amp;Browse</source>
        <translation>E&amp;xaminar</translation>
    </message>
</context>
<context>
    <name>DesktopPreferencesDialog</name>
    <message>
        <location filename="../desktop-preferences.ui" line="14"/>
        <source>Desktop Preferences</source>
        <translation>Preferencias del escritorio</translation>
    </message>
    <message>
        <location filename="../desktop-preferences.ui" line="24"/>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <location filename="../desktop-preferences.ui" line="229"/>
        <location filename="../desktop-preferences.ui" line="235"/>
        <source>Background</source>
        <translation>Fondo de pantalla</translation>
    </message>
    <message>
        <location filename="../desktop-preferences.ui" line="276"/>
        <source>Wallpaper mode:</source>
        <translation>Modo del fondo de pantalla:</translation>
    </message>
    <message>
        <location filename="../desktop-preferences.ui" line="299"/>
        <source>Wallpaper image file:</source>
        <translation>Seleccionar una imagen de fondo de pantalla:</translation>
    </message>
    <message>
        <location filename="../desktop-preferences.ui" line="241"/>
        <source>Select background color:</source>
        <translation>Seleccionar color de fondo:</translation>
    </message>
    <message>
        <location filename="../desktop-preferences.ui" line="308"/>
        <source>Image file</source>
        <translation>Archivo de imagen</translation>
    </message>
    <message>
        <location filename="../desktop-preferences.ui" line="314"/>
        <source>Image file path</source>
        <translation>Dirección del archivo de imagen</translation>
    </message>
    <message>
        <location filename="../desktop-preferences.ui" line="321"/>
        <source>&amp;Browse</source>
        <translation>E&amp;xaminar</translation>
    </message>
    <message>
        <location filename="../desktop-preferences.ui" line="30"/>
        <source>Icons</source>
        <translation>Configuración de iconos</translation>
    </message>
    <message>
        <location filename="../desktop-preferences.ui" line="36"/>
        <source>Icon size:</source>
        <translation>Tamaño:</translation>
    </message>
    <message>
        <location filename="../desktop-preferences.ui" line="49"/>
        <source>Label Text</source>
        <translation>Texto de las etiquetas de los iconos</translation>
    </message>
    <message>
        <location filename="../desktop-preferences.ui" line="113"/>
        <source>Select shadow color:</source>
        <translation>Seleccione el color de la sombra:</translation>
    </message>
    <message>
        <location filename="../desktop-preferences.ui" line="61"/>
        <source>Select font:</source>
        <translation>Seleccione el tipo de fuente:</translation>
    </message>
    <message>
        <location filename="../desktop-preferences.ui" line="136"/>
        <source>Spacing</source>
        <translation>Espacio entre los elementos</translation>
    </message>
    <message>
        <location filename="../desktop-preferences.ui" line="142"/>
        <source>Minimum item margins:</source>
        <translation>Márgenes mínimos de los elementos:</translation>
    </message>
    <message>
        <location filename="../desktop-preferences.ui" line="149"/>
        <source>3 px by default.</source>
        <translation>El valor predeterminado es de &quot;3 px&quot;.</translation>
    </message>
    <message>
        <location filename="../desktop-preferences.ui" line="152"/>
        <location filename="../desktop-preferences.ui" line="176"/>
        <source> px</source>
        <translation> px</translation>
    </message>
    <message>
        <location filename="../desktop-preferences.ui" line="165"/>
        <source>x</source>
        <translation>x</translation>
    </message>
    <message>
        <location filename="../desktop-preferences.ui" line="172"/>
        <source>1 px by default.
A space is also reserved for 3 lines of text.</source>
        <translation>El valor predeterminado es de &quot;1 px&quot;
También se reserva espacio para 3 líneas de texto.</translation>
    </message>
    <message>
        <location filename="../desktop-preferences.ui" line="189"/>
        <source>Lock</source>
        <translation>Bloquear</translation>
    </message>
    <message>
        <location filename="../desktop-preferences.ui" line="264"/>
        <source>Wallpaper</source>
        <translation>Fondo de pantalla</translation>
    </message>
    <message>
        <location filename="../desktop-preferences.ui" line="330"/>
        <source>Transform image based on EXIF data</source>
        <translation>Transformar la imagen a partir de los datos EXIF</translation>
    </message>
    <message>
        <location filename="../desktop-preferences.ui" line="357"/>
        <source>Slide Show</source>
        <translation>Pase de diapositivas</translation>
    </message>
    <message>
        <location filename="../desktop-preferences.ui" line="363"/>
        <source>Enable Slide Show</source>
        <translation>Habilitar el cambio de imagen automático</translation>
    </message>
    <message>
        <location filename="../desktop-preferences.ui" line="375"/>
        <source>Wallpaper image folder:</source>
        <translation>Seleccione la carpeta donde se encuentra el grupo de imágenes:</translation>
    </message>
    <message>
        <location filename="../desktop-preferences.ui" line="382"/>
        <source>Browse</source>
        <translation>Examinar</translation>
    </message>
    <message>
        <location filename="../desktop-preferences.ui" line="389"/>
        <source> hour(s)</source>
        <translation> hora(s)</translation>
    </message>
    <message>
        <location filename="../desktop-preferences.ui" line="399"/>
        <source>and</source>
        <translation>y</translation>
    </message>
    <message>
        <location filename="../desktop-preferences.ui" line="412"/>
        <source>Intervals less than 5min will be ignored</source>
        <translation>Si elige un intervalo menor a 5 minutos, este sera ignorado</translation>
    </message>
    <message>
        <location filename="../desktop-preferences.ui" line="415"/>
        <source>Interval:</source>
        <translation>Intervalo:</translation>
    </message>
    <message>
        <location filename="../desktop-preferences.ui" line="422"/>
        <source> minute(s)</source>
        <translation> minuto(s)</translation>
    </message>
    <message>
        <location filename="../desktop-preferences.ui" line="448"/>
        <source>Wallpaper folder</source>
        <translation>Carpeta de fondos de pantalla</translation>
    </message>
    <message>
        <location filename="../desktop-preferences.ui" line="471"/>
        <source>Randomize the slide show</source>
        <translation>Cambio de imagenes aleatorio</translation>
    </message>
    <message>
        <location filename="../desktop-preferences.ui" line="504"/>
        <source>Visible Shortcuts</source>
        <translation>Atajos del panel de navegación</translation>
    </message>
    <message>
        <location filename="../desktop-preferences.ui" line="510"/>
        <source>Home</source>
        <translation>Carpeta personal</translation>
    </message>
    <message>
        <location filename="../desktop-preferences.ui" line="521"/>
        <source>Trash</source>
        <translation>Papelera</translation>
    </message>
    <message>
        <location filename="../desktop-preferences.ui" line="532"/>
        <source>Computer</source>
        <translation>Sistema</translation>
    </message>
    <message>
        <location filename="../desktop-preferences.ui" line="543"/>
        <source>Network</source>
        <translation>Red</translation>
    </message>
    <message>
        <location filename="../desktop-preferences.ui" line="498"/>
        <source>Advanced</source>
        <translation>Avanzado</translation>
    </message>
    <message>
        <location filename="../desktop-preferences.ui" line="87"/>
        <source>Select text color:</source>
        <translation>Seleccione el color del texto:</translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../main-win.ui" line="14"/>
        <source>File Manager</source>
        <translation>Administrador de archivos</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="707"/>
        <source>Ctrl+Shift+N</source>
        <translation>Ctrl+Mayús+N</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="719"/>
        <source>Ctrl+Alt+N</source>
        <translation>Ctrl+Alt+N</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="724"/>
        <source>&amp;Find Files</source>
        <translation>&amp;Buscar archivos</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="727"/>
        <source>F3</source>
        <translation>F3</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="70"/>
        <source>&amp;File</source>
        <translation>&amp;Archivo</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="74"/>
        <source>C&amp;reate New</source>
        <translation>C&amp;rear nuevo</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="92"/>
        <source>&amp;Help</source>
        <translation>Ay&amp;uda</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="98"/>
        <location filename="../main-win.ui" line="120"/>
        <source>&amp;View</source>
        <translation>&amp;Ver</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="102"/>
        <source>&amp;Sorting</source>
        <translation>&amp;Ordenar</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="130"/>
        <source>&amp;Toolbars</source>
        <translation>Barras de herramien&amp;tas</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="137"/>
        <source>Path &amp;Bar</source>
        <translation>&amp;Barra de direcciones</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="144"/>
        <source>&amp;Filtering</source>
        <translation>&amp;Filtrado</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="165"/>
        <source>&amp;Edit</source>
        <translation>&amp;Editar</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="183"/>
        <source>&amp;Bookmarks</source>
        <translation>&amp;Marcadores</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="190"/>
        <source>&amp;Go</source>
        <translation>&amp;Ir</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="207"/>
        <source>&amp;Tool</source>
        <translation>&amp;Herramientas</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="228"/>
        <source>Main Toolbar</source>
        <translation>Barra de herramientas principal</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="262"/>
        <source>Go &amp;Up</source>
        <translation>S&amp;ubir</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="265"/>
        <source>Go Up</source>
        <translation>Subir</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="268"/>
        <source>Alt+Up</source>
        <translation>Alt+Arriba</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="277"/>
        <source>&amp;Home</source>
        <translation>Carpeta personal</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="280"/>
        <source>Alt+Home</source>
        <translation>Alt+Inicio</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="289"/>
        <source>&amp;Reload</source>
        <translation>&amp;Actualizar</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="292"/>
        <source>F5</source>
        <translation>F5</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="301"/>
        <source>Go</source>
        <translation>Ir</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="310"/>
        <source>Quit</source>
        <translation>Salir</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="319"/>
        <source>&amp;About</source>
        <translation>&amp;Acerca de</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="328"/>
        <source>&amp;New Window</source>
        <translation>&amp;Nueva ventana</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="331"/>
        <source>New Window</source>
        <translation>Nueva ventana</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="334"/>
        <source>Ctrl+N</source>
        <translation>Ctrl+N</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="342"/>
        <source>Show &amp;Hidden</source>
        <translation>Mo&amp;strar elementos ocultos</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="345"/>
        <source>Ctrl+H</source>
        <translation>Ctrl+H</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="354"/>
        <source>&amp;Computer</source>
        <translation>&amp;Sistema</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="363"/>
        <source>&amp;Trash</source>
        <translation>&amp;Papelera</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="368"/>
        <source>&amp;Network</source>
        <translation>&amp;Red</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="377"/>
        <source>&amp;Desktop</source>
        <translation>&amp;Escritorio</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="386"/>
        <source>&amp;Add to Bookmarks</source>
        <translation>&amp;Añadir a marcadores</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="391"/>
        <source>&amp;Applications</source>
        <translation>&amp;Aplicaciones</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="396"/>
        <source>Reload</source>
        <translation>Actualizar</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="404"/>
        <source>&amp;Icon View</source>
        <translation>Ver &amp;iconos medianos</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="412"/>
        <source>&amp;Compact View</source>
        <translation>Ver lista &amp;compacta</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="420"/>
        <source>&amp;Detailed List</source>
        <translation>Ver lista &amp;detallada</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="428"/>
        <source>&amp;Thumbnail View</source>
        <translation>Ver &amp;miniaturas grandes</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="437"/>
        <source>Cu&amp;t</source>
        <translation>Cor&amp;tar</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="440"/>
        <source>Ctrl+X</source>
        <translation>Ctrl+X</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="449"/>
        <source>&amp;Copy</source>
        <translation>&amp;Copiar</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="452"/>
        <source>Ctrl+C</source>
        <translation>Ctrl+C</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="461"/>
        <source>&amp;Paste</source>
        <translation>&amp;Pegar</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="464"/>
        <source>Ctrl+V</source>
        <translation>Ctrl+V</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="469"/>
        <source>Select &amp;All</source>
        <translation>Seleccion&amp;ar todo</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="472"/>
        <source>Ctrl+A</source>
        <translation>Ctrl+A</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="477"/>
        <source>Pr&amp;eferences</source>
        <translation>Pr&amp;eferencias</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="485"/>
        <source>&amp;Ascending</source>
        <translation>&amp;Ascendente</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="493"/>
        <source>&amp;Descending</source>
        <translation>&amp;Descendente</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="501"/>
        <source>&amp;By File Name</source>
        <translation>Por nombre de archivo</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="509"/>
        <source>By &amp;Modification Time</source>
        <translation>Por fecha de &amp;modificación</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="517"/>
        <source>By Deletio&amp;n Time</source>
        <translation>Por fecha de eliminació&amp;n</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="525"/>
        <source>By File &amp;Type</source>
        <translation>Por &amp;tipo de archivo</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="533"/>
        <source>By &amp;Owner</source>
        <translation>Dependiendo del propietari&amp;o</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="541"/>
        <source>By &amp;Group</source>
        <translation>Por &amp;grupo</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="549"/>
        <source>&amp;Folder First</source>
        <translation>Siempre ubicar las carpetas primero</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="557"/>
        <source>&amp;Preserve sorting for this folder</source>
        <translation>Recordar el orden de esta car&amp;peta</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="656"/>
        <source>&amp;Case Sensitive</source>
        <translation>Tener en cuenta mayús&amp;culas y minúsculas</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="664"/>
        <source>By File &amp;Size</source>
        <translation>Por tamaño de archivo</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="669"/>
        <source>&amp;Close Window</source>
        <translation>&amp;Cerrar la ventana</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="672"/>
        <source>Ctrl+Q</source>
        <translation>Ctrl+Q</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="704"/>
        <source>&amp;Folder</source>
        <translation>Carpeta</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="716"/>
        <source>&amp;Blank File</source>
        <translation>Archivo vacío</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="840"/>
        <source>&amp;Show/Focus Filter Bar</source>
        <translation>Mo&amp;strar/Enfocar la barra de filtrado</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="843"/>
        <source>Show Filter Bar</source>
        <translation>Mostrar la barra de filtrado</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="846"/>
        <source>Ctrl+I</source>
        <translation>Ctrl+L</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="854"/>
        <source>S&amp;plit View</source>
        <translation>Dividir la ventana en dos</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="857"/>
        <source>Split View</source>
        <translation>Dividir la ventana en dos</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="860"/>
        <source>F6</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="865"/>
        <source>&amp;Copy Full Path</source>
        <translation>&amp;Copiar la dirección completa</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="868"/>
        <source>Ctrl+Shift+C</source>
        <translation>Ctrl+Mayús+C</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="879"/>
        <source>Show Thumb&amp;nails</source>
        <translation>Mostrar mi&amp;niaturas</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="882"/>
        <source>Show Thumbnails</source>
        <translation>Mostrar miniaturas</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="738"/>
        <source>Ctrl+B</source>
        <translation>Ctrl+B</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="743"/>
        <source>&amp;Clear All Filters</source>
        <translation>Borrar todos los filtros</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="746"/>
        <source>Ctrl+Shift+K</source>
        <translation>Ctrl+Mayús+K</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="755"/>
        <source>Close &amp;previous tabs</source>
        <translation>Cerrar las &amp;pestañas anteriores</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="764"/>
        <source>Close &amp;next tabs</source>
        <translation>Cerrar las pestañas siguie&amp;ntes</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="803"/>
        <source>&amp;Preserve Settings for This Folder</source>
        <translation>Recordar la configuración de esta car&amp;peta</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="808"/>
        <source>Connect to &amp;Server</source>
        <translation>Conectar a un &amp;servidor</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="816"/>
        <source>&amp;Location</source>
        <translation>Utilizar texto</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="824"/>
        <source>&amp;Path Buttons</source>
        <translation>Utilizar botones</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="829"/>
        <source>&amp;Bulk Rename</source>
        <translation>Renom&amp;brar varios</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="832"/>
        <source>Bulk Rename</source>
        <translation>Renombrar varios</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="835"/>
        <source>Ctrl+F2</source>
        <translation>Ctrl+F2</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="769"/>
        <source>Close &amp;other tabs</source>
        <translation>Cerrar todas las &amp;otras pestañas</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="735"/>
        <source>Permanent &amp;filter bar</source>
        <translation>Barra de &amp;filtrado permanente</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="777"/>
        <source>&amp;Menu bar</source>
        <translation>Barra de &amp;menú</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="780"/>
        <source>Menu bar</source>
        <translation>Barra de menú</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="783"/>
        <source>Ctrl+M</source>
        <translation>Ctrl+M</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="792"/>
        <location filename="../main-win.ui" line="795"/>
        <source>Menu</source>
        <translation>Menú</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="566"/>
        <source>New &amp;Tab</source>
        <translation>Nueva &amp;pestaña</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="569"/>
        <source>New Tab</source>
        <translation>Nueva pestaña</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="572"/>
        <source>Ctrl+T</source>
        <translation>Ctrl+T</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="581"/>
        <source>Go &amp;Back</source>
        <translation>Re&amp;troceder</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="584"/>
        <source>Go Back</source>
        <translation>Retroceder</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="587"/>
        <source>Alt+Left</source>
        <translation>Alt+Izquierda</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="596"/>
        <source>Go &amp;Forward</source>
        <translation>A&amp;vanzar</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="599"/>
        <source>Go Forward</source>
        <translation>Avanzar</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="602"/>
        <source>Alt+Right</source>
        <translation>Alt+Derecha</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="607"/>
        <source>&amp;Invert Selection</source>
        <translation>&amp;Invertir la selección</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="616"/>
        <source>&amp;Delete</source>
        <translation>&amp;Eliminar</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="619"/>
        <source>Del</source>
        <translation>Supr</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="624"/>
        <source>&amp;Rename</source>
        <translation>&amp;Renombrar</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="627"/>
        <source>F2</source>
        <translation>F2</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="632"/>
        <source>C&amp;lose Tab</source>
        <translation>&amp;Cerrar pestaña</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="635"/>
        <source>Ctrl+W</source>
        <translation>Ctrl+W</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="640"/>
        <source>File &amp;Properties</source>
        <translation>Propiedades del &amp;archivo</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="643"/>
        <source>Alt+Return</source>
        <translation>Alt+Enter</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="648"/>
        <source>&amp;Folder Properties</source>
        <translation>&amp;Propiedades de la &amp;carpeta</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="677"/>
        <source>Edit Bookmarks</source>
        <translation>Editar los marcadores</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="682"/>
        <source>Open &amp;Terminal</source>
        <translation>Abrir en un emulador de &amp;terminal</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="685"/>
        <source>F4</source>
        <translation>F4</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="690"/>
        <source>Open as &amp;Root</source>
        <translation>Abrir con permisos de administrado&amp;r</translation>
    </message>
    <message>
        <location filename="../main-win.ui" line="695"/>
        <source>&amp;Edit Bookmarks</source>
        <translation>&amp;Editar los marcadores</translation>
    </message>
</context>
<context>
    <name>PCManFM::Application</name>
    <message>
        <location filename="../application.cpp" line="165"/>
        <source>Name of configuration profile</source>
        <translation>Nombre del perfil de configuración</translation>
    </message>
    <message>
        <location filename="../application.cpp" line="165"/>
        <source>PROFILE</source>
        <translation>Perfil</translation>
    </message>
    <message>
        <location filename="../application.cpp" line="168"/>
        <source>Run PCManFM as a daemon</source>
        <translation>Ejecutar PCManFM como un servicio</translation>
    </message>
    <message>
        <location filename="../application.cpp" line="171"/>
        <source>Quit PCManFM</source>
        <translation>Cerrar PCManFM</translation>
    </message>
    <message>
        <location filename="../application.cpp" line="174"/>
        <source>Launch desktop manager</source>
        <translation>Abrir el administrador del escritorio</translation>
    </message>
    <message>
        <location filename="../application.cpp" line="177"/>
        <source>Turn off desktop manager if it&apos;s running</source>
        <translation>Cerrar el administrador del escritorio si está en ejecución</translation>
    </message>
    <message>
        <location filename="../application.cpp" line="180"/>
        <source>Open desktop preference dialog on the page with the specified name</source>
        <translation>Abrir la ventana de preferencias del escritorio en la página especificada</translation>
    </message>
    <message>
        <location filename="../application.cpp" line="180"/>
        <location filename="../application.cpp" line="195"/>
        <source>NAME</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <location filename="../application.cpp" line="183"/>
        <source>Open new window</source>
        <translation>Abrir una nueva ventana</translation>
    </message>
    <message>
        <location filename="../application.cpp" line="186"/>
        <source>Open Find Files utility</source>
        <translation>Abrir la aplicación de búsqueda</translation>
    </message>
    <message>
        <location filename="../application.cpp" line="189"/>
        <source>Set desktop wallpaper from image FILE</source>
        <translation>Establecer un archivo de imagen de fondo de escritorio</translation>
    </message>
    <message>
        <location filename="../application.cpp" line="189"/>
        <source>FILE</source>
        <translation>Archivo</translation>
    </message>
    <message>
        <location filename="../application.cpp" line="192"/>
        <source>MODE</source>
        <translation>Modo</translation>
    </message>
    <message>
        <location filename="../application.cpp" line="192"/>
        <source>Set mode of desktop wallpaper. MODE=(%1)</source>
        <translation>Establecer el modo del fondo de pantalla del escritorio. Modo=(%1)</translation>
    </message>
    <message>
        <location filename="../application.cpp" line="195"/>
        <source>Open Preferences dialog on the page with the specified name</source>
        <translation>Abrir la ventana de preferencias en la página con el nombre dado</translation>
    </message>
    <message>
        <location filename="../application.cpp" line="198"/>
        <source>Files or directories to open</source>
        <translation>Archivos o directorios a abrir</translation>
    </message>
    <message>
        <location filename="../application.cpp" line="198"/>
        <source>[FILE1, FILE2,...]</source>
        <translation>[Archivo 1, Archivo 2, ...]</translation>
    </message>
    <message>
        <location filename="../application.cpp" line="545"/>
        <location filename="../application.cpp" line="550"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../application.cpp" line="550"/>
        <source>Terminal emulator is not set.</source>
        <translation>No hay ningún emulador de terminal configurado.</translation>
    </message>
</context>
<context>
    <name>PCManFM::AutoRunDialog</name>
    <message>
        <location filename="../autorundialog.cpp" line="44"/>
        <source>Open in file manager</source>
        <translation>Abrir en el administrador de archivos</translation>
    </message>
    <message>
        <location filename="../autorundialog.cpp" line="137"/>
        <source>Removable Disk</source>
        <translation>Disco removible</translation>
    </message>
</context>
<context>
    <name>PCManFM::ConnectServerDialog</name>
    <message>
        <location filename="../connectserverdialog.cpp" line="9"/>
        <source>SSH</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../connectserverdialog.cpp" line="10"/>
        <source>FTP</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../connectserverdialog.cpp" line="11"/>
        <source>WebDav</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../connectserverdialog.cpp" line="12"/>
        <source>Secure WebDav</source>
        <translation>WebDav seguro</translation>
    </message>
    <message>
        <location filename="../connectserverdialog.cpp" line="13"/>
        <source>HTTP</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../connectserverdialog.cpp" line="14"/>
        <source>HTTPS</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>PCManFM::DesktopEntryDialog</name>
    <message>
        <location filename="../desktopentrydialog.cpp" line="26"/>
        <source>Command:</source>
        <translation>Comando:</translation>
    </message>
    <message>
        <location filename="../desktopentrydialog.cpp" line="29"/>
        <source>URL:</source>
        <translation>URL:</translation>
    </message>
    <message>
        <location filename="../desktopentrydialog.cpp" line="54"/>
        <source>Select an icon</source>
        <translation>Seleccione un icono</translation>
    </message>
    <message>
        <location filename="../desktopentrydialog.cpp" line="56"/>
        <source>Images (*.png *.xpm *.svg *.svgz )</source>
        <translation>Imágenes (*.png *.xpm *.svg *.svgz )</translation>
    </message>
    <message>
        <location filename="../desktopentrydialog.cpp" line="78"/>
        <source>Select an executable file</source>
        <translation>Seleccione un archivo ejecutable</translation>
    </message>
    <message>
        <location filename="../desktopentrydialog.cpp" line="86"/>
        <source>Select a file</source>
        <translation>Seleccione un archivo</translation>
    </message>
</context>
<context>
    <name>PCManFM::DesktopPreferencesDialog</name>
    <message>
        <location filename="../desktoppreferencesdialog.cpp" line="53"/>
        <source>Fill with background color only</source>
        <translation>Utilizar un color solido de fondo de escritorio</translation>
    </message>
    <message>
        <location filename="../desktoppreferencesdialog.cpp" line="54"/>
        <source>Stretch to fill the entire screen</source>
        <translation>Expandir estirando la imagen hasta los bordes</translation>
    </message>
    <message>
        <location filename="../desktoppreferencesdialog.cpp" line="55"/>
        <source>Stretch to fit the screen</source>
        <translation>Ajustar la imagen hasta el borde sin estirar</translation>
    </message>
    <message>
        <location filename="../desktoppreferencesdialog.cpp" line="56"/>
        <source>Center on the screen</source>
        <translation>Centrar la imagen en la pantalla sin ajustar</translation>
    </message>
    <message>
        <location filename="../desktoppreferencesdialog.cpp" line="57"/>
        <source>Tile the image to fill the entire screen</source>
        <translation>Mosaico repitiendo la imagen en la pantalla</translation>
    </message>
    <message>
        <location filename="../desktoppreferencesdialog.cpp" line="58"/>
        <source>Zoom the image to fill the entire screen</source>
        <translation>Rellenar la pantalla ampliando la imagen</translation>
    </message>
    <message>
        <location filename="../desktoppreferencesdialog.cpp" line="231"/>
        <source>Select Wallpaper</source>
        <translation>Seleccione un fondo de pantalla</translation>
    </message>
    <message>
        <location filename="../desktoppreferencesdialog.cpp" line="235"/>
        <source>Image Files</source>
        <translation>Archivos de imagen</translation>
    </message>
</context>
<context>
    <name>PCManFM::DesktopWindow</name>
    <message>
        <location filename="../desktopwindow.cpp" line="297"/>
        <source>Trash (One item)</source>
        <translation>Papelera (un elemento)</translation>
    </message>
    <message numerus="yes">
        <location filename="../desktopwindow.cpp" line="300"/>
        <source>Trash (%Ln items)</source>
        <translation>
            <numerusform>Papelera (%Ln elemento)</numerusform>
            <numerusform>Papelera (%Ln elementos)</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../desktopwindow.cpp" line="304"/>
        <source>Trash (Empty)</source>
        <translation>Papelera</translation>
    </message>
    <message>
        <location filename="../desktopwindow.cpp" line="332"/>
        <source>Computer</source>
        <translation>Sistema</translation>
    </message>
    <message>
        <location filename="../desktopwindow.cpp" line="346"/>
        <source>Network</source>
        <translation>Red</translation>
    </message>
    <message>
        <location filename="../desktopwindow.cpp" line="851"/>
        <source>Open</source>
        <translation>Abrir</translation>
    </message>
    <message>
        <location filename="../desktopwindow.cpp" line="856"/>
        <location filename="../desktopwindow.cpp" line="893"/>
        <source>Stic&amp;k to Current Position</source>
        <translation>&amp;Fijar icono en la posición actual</translation>
    </message>
    <message>
        <location filename="../desktopwindow.cpp" line="863"/>
        <source>Empty Trash</source>
        <translation>Vaciar la papelera</translation>
    </message>
    <message>
        <location filename="../desktopwindow.cpp" line="919"/>
        <source>Hide Desktop Items</source>
        <translation>Ocultar los elementos del escritorio</translation>
    </message>
    <message>
        <location filename="../desktopwindow.cpp" line="925"/>
        <source>Create Launcher</source>
        <translation>Crear un lanzador</translation>
    </message>
    <message>
        <location filename="../desktopwindow.cpp" line="928"/>
        <source>Desktop Preferences</source>
        <translation>Preferencias del escritorio</translation>
    </message>
</context>
<context>
    <name>PCManFM::FilterBar</name>
    <message>
        <location filename="../tabpage.cpp" line="92"/>
        <source>Filter:</source>
        <translation>Filtro:</translation>
    </message>
</context>
<context>
    <name>PCManFM::FilterEdit</name>
    <message>
        <location filename="../tabpage.cpp" line="62"/>
        <source>Clear text (Ctrl+K or Esc)</source>
        <translation>Borrar el texto (Ctrl+K o Esc)</translation>
    </message>
</context>
<context>
    <name>PCManFM::MainWindow</name>
    <message>
        <location filename="../mainwindow.cpp" line="139"/>
        <source>Root Instance</source>
        <translation>Permisos de administrador activados</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="675"/>
        <source>Hide menu bar</source>
        <translation>Ocultar la barra de menú</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="676"/>
        <source>This will hide the menu bar completely, use Ctrl+M to show it again.</source>
        <translation>El comando utilizado ocultara permanentemente la barra de menú,
en su lugar se agregará un boton en la esquina superior derecha
donde podrá acceder a todos los menús de la barra.

Puede revertirlo utilizando Ctrl+M para mostrar la barra de nuevo.</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1007"/>
        <source>Version: %1</source>
        <translation>Versión: %1</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="172"/>
        <location filename="../mainwindow.cpp" line="1856"/>
        <source>&amp;Move to Trash</source>
        <translation>&amp;Eliminar</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="172"/>
        <location filename="../mainwindow.cpp" line="1856"/>
        <source>&amp;Delete</source>
        <translation>&amp;Eliminar</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1913"/>
        <location filename="../mainwindow.cpp" line="1921"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../mainwindow.cpp" line="1921"/>
        <source>Switch user command is not set.</source>
        <translation>No se ha definido ningún comando para cambiar de usuario.</translation>
    </message>
</context>
<context>
    <name>PCManFM::PreferencesDialog</name>
    <message>
        <location filename="../preferencesdialog.cpp" line="196"/>
        <source>Icon View</source>
        <translation>Ver iconos medianos</translation>
    </message>
    <message>
        <location filename="../preferencesdialog.cpp" line="197"/>
        <source>Compact View</source>
        <translation>Ver lista compacta</translation>
    </message>
    <message>
        <location filename="../preferencesdialog.cpp" line="198"/>
        <source>Thumbnail View</source>
        <translation>Ver miniaturas grandes</translation>
    </message>
    <message>
        <location filename="../preferencesdialog.cpp" line="199"/>
        <source>Detailed List View</source>
        <translation>Ver lista detallada</translation>
    </message>
</context>
<context>
    <name>PCManFM::TabPage</name>
    <message>
        <location filename="../tabpage.cpp" line="420"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../tabpage.cpp" line="429"/>
        <source>Free space: %1 (Total: %2)</source>
        <translation>Espacio libre: %1 (Total %2)</translation>
    </message>
    <message numerus="yes">
        <location filename="../tabpage.cpp" line="446"/>
        <source>%n item(s)</source>
        <translation>
            <numerusform>%n elemento</numerusform>
            <numerusform>%n elementos</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../tabpage.cpp" line="448"/>
        <source> (%n hidden)</source>
        <translation>
            <numerusform> (%n oculto)</numerusform>
            <numerusform> (%n ocultos)</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../tabpage.cpp" line="453"/>
        <location filename="../tabpage.cpp" line="639"/>
        <location filename="../tabpage.cpp" line="655"/>
        <source>Link to</source>
        <translation>Enlazar a</translation>
    </message>
    <message numerus="yes">
        <location filename="../tabpage.cpp" line="669"/>
        <source>%n item(s) selected</source>
        <translation>
            <numerusform>%n elemento seleccionado</numerusform>
            <numerusform>%n elementos seleccionados</numerusform>
        </translation>
    </message>
</context>
<context>
    <name>PCManFM::View</name>
    <message>
        <location filename="../view.cpp" line="56"/>
        <source>Many files</source>
        <translation>Muchos archivos</translation>
    </message>
    <message>
        <location filename="../view.cpp" line="57"/>
        <source>Do you want to open these %1 file?</source>
        <translation>¿Quiere abrir esos %1 archivos?</translation>
    </message>
    <message>
        <location filename="../view.cpp" line="122"/>
        <source>Open in New T&amp;ab</source>
        <translation>&amp;Abrir en una pestaña nueva</translation>
    </message>
    <message>
        <location filename="../view.cpp" line="126"/>
        <source>Open in New Win&amp;dow</source>
        <translation>Abrir en una &amp;ventana nueva</translation>
    </message>
    <message>
        <location filename="../view.cpp" line="134"/>
        <source>Open in Termina&amp;l</source>
        <translation>Abrir en un termina&amp;l</translation>
    </message>
</context>
<context>
    <name>PreferencesDialog</name>
    <message>
        <location filename="../preferences.ui" line="14"/>
        <source>Preferences</source>
        <translation>Preferencias</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="45"/>
        <source>User Interface</source>
        <translation>Interfaz de usuario</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="35"/>
        <source>Behavior</source>
        <translation>Comportamiento</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="50"/>
        <location filename="../preferences.ui" line="551"/>
        <source>Thumbnail</source>
        <translation>Miniaturas</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="55"/>
        <source>Volume</source>
        <translation>Discos removibles</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="60"/>
        <source>Advanced</source>
        <translation>Avanzado</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="206"/>
        <source>Select newly created files</source>
        <translation>Seleccionar los archivos después de haber sido creados</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="233"/>
        <source>Icons</source>
        <translation>Iconos</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="265"/>
        <source>Size of big icons:</source>
        <translation>Tamaño de los iconos medianos:</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="282"/>
        <source>Size of small icons:</source>
        <translation>Tamaño de los iconos pequeños:</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="299"/>
        <source>Size of thumbnails:</source>
        <translation>Tamaño de las miniaturas e iconos grandes:</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="313"/>
        <source>Size of side pane icons:</source>
        <translation>Tamaño de los iconos del panel lateral:</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="245"/>
        <source>Icon theme:</source>
        <translation>Tema de iconos:</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="469"/>
        <source>Window</source>
        <translation>Ventana</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="482"/>
        <source>Always show the tab bar</source>
        <translation>Mostrar siempre la barra de pestañas</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="489"/>
        <source>Show &apos;Close&apos; buttons on tabs	</source>
        <translation>Mostrar el botón cerrar en las pestañas	</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="496"/>
        <source>Remember the size of the last closed window</source>
        <translation>Recordar el tamaño de la última ventana cerrada</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="503"/>
        <source>Default width of new windows:</source>
        <translation>Ancho predeterminado de las ventanas nuevas:</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="517"/>
        <source>Default height of new windows:</source>
        <translation>Alto predeterminado de las ventanas nuevas:</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="81"/>
        <source>Browsing</source>
        <translation>Navegación</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="93"/>
        <source>Open files with single click</source>
        <translation>Abrir los archivos haciendo solo un clic</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="103"/>
        <source>Delay of auto-selection in single click mode (0 to disable)</source>
        <translation>Demora en la selección automática. (si elige &quot;0,00 s&quot; sera inhabilitado)</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="110"/>
        <source>Default view mode:</source>
        <translation>Visualización predeterminada de los iconos:</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="123"/>
        <source> sec</source>
        <translation> s</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="162"/>
        <source>File Operations</source>
        <translation>Operaciones de archivos</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="168"/>
        <source>Confirm before deleting files</source>
        <translation>Pedir confirmación antes de borrar los archivos</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="175"/>
        <source>Move deleted files to &quot;trash bin&quot; instead of erasing from disk.</source>
        <translation>Mover los archivos a la papelera en lugar de eliminarlos del disco.</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="584"/>
        <source>Show thumbnails of files</source>
        <translation>Mostrar miniaturas grandes de archivos de imagen</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="574"/>
        <source>Only show thumbnails for local files</source>
        <translation>Solo mostrar miniaturas de archivos locales</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="40"/>
        <source>Display</source>
        <translation>Pantalla</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="90"/>
        <source>If this is unchecked, the DE setting will be used.</source>
        <translation>Si está desmarcado, se usará la configuración del entorno de escritorio.</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="133"/>
        <source>Bookmarks:</source>
        <translation>Como desea que se abran los marcadores:</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="141"/>
        <source>Open in current tab</source>
        <translation>En la pestaña actual</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="146"/>
        <source>Open in new tab</source>
        <translation>En una pestaña nueva</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="151"/>
        <source>Open in new window</source>
        <translation>En una ventana nueva</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="182"/>
        <source>Erase files on removable media instead of &quot;trash can&quot; creation</source>
        <translation>Borrar los archivos de medios removibles en vez de enviar a la papelera</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="189"/>
        <source>Confirm before moving files into &quot;trash can&quot;</source>
        <translation>Pedir confirmación antes de mover archivos a la papelera</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="196"/>
        <location filename="../preferences.ui" line="346"/>
        <location filename="../preferences.ui" line="356"/>
        <source>Requires application restart to take effect completely</source>
        <translation>Es necesario reiniciar la aplicación para que los cambios tengan efecto</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="199"/>
        <source>Launch executable files without prompt</source>
        <translation>Iniciar los archivos ejecutables sin preguntar</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="262"/>
        <location filename="../preferences.ui" line="272"/>
        <source>Used by Icon View</source>
        <translation>Este tamaño de iconos solo sera utilizado cuando se
seleccione la vista de iconos medianos</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="279"/>
        <location filename="../preferences.ui" line="289"/>
        <source>Used by Compact View and Detailed List View</source>
        <translation>Este tamaño de iconos sera utilizado cuando seleccione que se
vea en modo lista compacta o el modo lista detallada</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="296"/>
        <location filename="../preferences.ui" line="306"/>
        <source>Used by Thumbnail View</source>
        <translation>Este tamaño de icono sera utilizado cuando seleccione el modo
miniaturas grandes, afecta tanto a las imagenes como a las carpetas</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="326"/>
        <source>User interface</source>
        <translation>Interfaz de usuario</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="339"/>
        <source>Treat backup files as hidden</source>
        <translation>Tratar los archivos de respaldo como si fueran ocultos</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="349"/>
        <source>Always show full file names</source>
        <translation>Mostrar siempre los nombres de archivo completos</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="359"/>
        <source>Show icons of hidden files shadowed</source>
        <translation>Mostrar sombreados los iconos de archivos que estén ocultos</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="382"/>
        <source>Minimum item margins in icon view:</source>
        <translation>Márgenes mínimos de los iconos en tamaño mediano:</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="389"/>
        <source>3 px by default.</source>
        <translation>El valor predeterminado de este campo es de &quot;3 px&quot;.</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="392"/>
        <location filename="../preferences.ui" line="416"/>
        <source> px</source>
        <translation> px</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="405"/>
        <source>x</source>
        <translation>x</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="412"/>
        <source>3 px by default.
A space is also reserved for 3 lines of text.</source>
        <translation>El valor predeterminado de este campo es de &quot;3 px&quot;.
También se reserva espacio para 3 líneas de texto.</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="429"/>
        <source>Lock</source>
        <translation>Unir valores</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="478"/>
        <source>When unchecked, the tab bar will be shown
only if there are more than one tab.</source>
        <translation>Si desactiva esta opción, la barra de pestañas solo sera
visible cuando haya más de una pestaña abierta.</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="710"/>
        <source>Examples:&lt;br&gt;For terminal: &lt;i&gt;xterm -e %s&lt;/i&gt;&lt;br&gt;For switching user: &lt;i&gt;lxsudo %s&lt;/i&gt; or &lt;i&gt;lxsudo dbus-run-session -- %s&lt;/i&gt;&lt;br&gt;&lt;i&gt;%s&lt;/i&gt; is the command line you want to execute with terminal or su.&lt;br&gt; Important: Please use lxsudo, sudo alone will wreck permissions of the settings file.</source>
        <translation>Ejemplos:&lt;br&gt;Para terminal: &lt;i&gt;xterm -e %s&lt;/i&gt;&lt;br&gt;Para cambiar de usuario: &lt;i&gt;lxsudo %s&lt;/i&gt; o &lt;i&gt;lxsudo dbus-run-session -- %s&lt;/i&gt;&lt;br&gt;&lt;i&gt;%s&lt;/i&gt; es el comando que quiere ejecutar en la terminal o su.&lt;br&gt; Importante: use lxsudo, «sudo» por sí solo estropea los permisos del archivo de configuración.</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="801"/>
        <source>Application restart is needed for changes to take effect.</source>
        <translation>Es necesario reiniciar la aplicación para que los cambios tengan efecto.</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="557"/>
        <source>Do not generate thumbnails for image files exceeding this size:</source>
        <translation>No generar imagenes en miniatura cuando los archivos superen los:</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="564"/>
        <source> KB</source>
        <translation> KB</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="581"/>
        <source>Needs ffmpegthumbnailer</source>
        <translation>Para que esta característica funcione correctamente, debe
tener instalada la aplicación &quot;ffmpegthumbnailer&quot;, si no esta
instalada puede buscarla en su gestor de paquetes</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="611"/>
        <source>Auto Mount</source>
        <translation>Montar automáticamente</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="617"/>
        <source>Mount mountable volumes automatically on program startup</source>
        <translation>Montar discos removibles y unidades USB automáticamente al inicio</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="624"/>
        <source>Mount removable media automatically when they are inserted</source>
        <translation>Montar discos removibles y unidades USB automáticamente cuando se insertan</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="631"/>
        <source>Show available options for removable media when they are inserted</source>
        <translation>Mostrar opciones disponibles sobre que hacer al insertarlos</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="641"/>
        <source>When removable medium unmounted:</source>
        <translation>Configuración de desconexión del disco o unidad USB:</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="647"/>
        <source>Close &amp;tab containing removable medium</source>
        <translation>Cerrar la pes&amp;taña del medio removible al desconectar la unidad</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="654"/>
        <source>Chan&amp;ge folder in the tab to home folder</source>
        <translation>Cambiar la pestaña a la carpeta personal al desconectar la unidad</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="697"/>
        <source>Switch &amp;user command:</source>
        <translation>Comando para cambiar de &amp;usuario:</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="723"/>
        <source>Archiver in&amp;tegration:</source>
        <translation>Archivador in&amp;tegrado al sistema:</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="746"/>
        <source>Templates</source>
        <translation>Plantillas</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="752"/>
        <source>Show only user defined templates in menu</source>
        <translation>Mostrar solo plantillas del usuario en el menú</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="759"/>
        <source>Show only one template for each MIME type</source>
        <translation>Mostrar una sola plantilla para cada tipo de archivo</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="766"/>
        <source>Run default application after creation from template</source>
        <translation>Ejecutar la aplicación predeterminada tras crear una plantilla</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="681"/>
        <source>Programs</source>
        <translation>Aplicaciones predeterminadas</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="690"/>
        <source>Terminal emulator:</source>
        <translation>Aplicación predeterminada para el terminal:</translation>
    </message>
    <message>
        <location filename="../preferences.ui" line="332"/>
        <source>Use SI decimal prefixes instead of IEC binary prefixes</source>
        <translation>Usar prefijos decimales SI en lugar de prefijos binarios IEC</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../bulkrename.cpp" line="73"/>
        <source>Renaming files...</source>
        <translation>Renombrando archivos...</translation>
    </message>
    <message>
        <location filename="../bulkrename.cpp" line="73"/>
        <source>Abort</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../bulkrename.cpp" line="82"/>
        <source>Warning</source>
        <translation>Advertencia</translation>
    </message>
    <message>
        <location filename="../bulkrename.cpp" line="82"/>
        <source>Renaming is aborted.</source>
        <translation>Se han cancelado los cambios en los nombres.</translation>
    </message>
    <message>
        <location filename="../bulkrename.cpp" line="104"/>
        <location filename="../bulkrename.cpp" line="107"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../bulkrename.cpp" line="104"/>
        <source>No file could be renamed.</source>
        <translation>No se ha podido renombrar ningún archivo.</translation>
    </message>
    <message>
        <location filename="../bulkrename.cpp" line="107"/>
        <source>Some files could not be renamed.</source>
        <translation>Algunos archivos no se han podido renombrar.</translation>
    </message>
</context>
</TS>
